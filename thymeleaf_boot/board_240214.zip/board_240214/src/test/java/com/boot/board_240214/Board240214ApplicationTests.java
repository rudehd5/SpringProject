package com.boot.board_240214;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Board240214ApplicationTests {

	@Test
	void contextLoads() {
	}

}
