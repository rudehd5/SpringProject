package org.example.springreact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringReactApplicationTests {

	@Test
	void contextLoads() {
	}

}
