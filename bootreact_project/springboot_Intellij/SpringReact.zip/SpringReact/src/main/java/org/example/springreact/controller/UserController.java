package org.example.springreact.controller;

import lombok.extern.slf4j.Slf4j;
import org.example.springreact.model.User;
import org.example.springreact.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("/api/signUp")
    public int signUp(@RequestBody User user) {
        try {
            userService.save(user);
            return 1; // 성공
        } catch (Exception e) {
            e.printStackTrace();
            return 0; // 실패
        }
    }
//    @ResponseBody
//    @RequestMapping(value="/api/signUp")
//    public ResponseEntity<String> addMem(@RequestBody User user) {
//        userService.save(user);
//
//        return ResponseEntity.ok("성공");
//    }
}
