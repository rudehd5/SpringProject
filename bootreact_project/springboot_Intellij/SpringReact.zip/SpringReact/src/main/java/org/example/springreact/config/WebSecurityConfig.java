package org.example.springreact.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.sql.DataSource;

@Configuration
@EnableWebSecurity
//public class WebSecurityConfig {
public class WebSecurityConfig implements WebMvcConfigurer {

    @Autowired
    private DataSource dataSource;


    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Override
    public void addCorsMappings(CorsRegistry registry){
        registry.addMapping("/**") // cors를 적용할 spring서버의 url 패턴.
//                .allowedOrigins("http://localhost:3000") // cors를 허용할 도메인. 제한을 모두 해제하려면 "**"
                .allowedOrigins("*") // cors를 허용할 도메인. 제한을 모두 해제하려면 "**"
                .allowedMethods("GET","POST","PUT", "DELETE") // cors를 허용할 method
                .maxAge(3000);
    }
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests((requests) -> requests
                                // 허용되는 url
//                        .requestMatchers("/", "/home").permitAll()
//                        .requestMatchers("/", "/css/**").permitAll()
//                        .requestMatchers("/", "/css/**", "/images/**").permitAll()
//                                .requestMatchers("/", "/css/**", "/images/**", "/register").permitAll()
                                .requestMatchers("/", "/css/**", "/images/**", "/register", "/api/**").permitAll()
//                        .requestMatchers("/", "/api/delete/").permitAll()
                                .anyRequest().authenticated()
                )
                // 허가되지 않은 경우 url 이동
//                .formLogin((form) -> form
////                        .loginPage("/login")
//                                .loginPage("/login")
//                                .permitAll()
//                )
                .logout((logout) -> logout.permitAll());

        return http.build();
    }
//    @Override
//    public void addCorsMappings(CorsRegistry registry) {
//        registry.addMapping("/api/signUp/**") // v1/books/ 경로에 대해서 CORS 설정
//                .allowedOrigins("http://localhost:3000") // 리액트 애플리케이션의 도메인을 설정
//                .allowedMethods("GET", "POST", "PUT", "DELETE")
//                .allowCredentials(true);
//
//        registry.addMapping("/api/login/**") // v1/reviews/ 경로에 대해서 CORS 설정
//                .allowedOrigins("http://localhost:3000") // 리액트 애플리케이션의 도메인을 설정
//                .allowedMethods("GET", "POST", "PUT", "DELETE")
//                .allowCredentials(true);
//    }
}
